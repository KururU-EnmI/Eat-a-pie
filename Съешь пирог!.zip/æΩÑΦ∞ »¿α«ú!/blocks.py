# Импортируем библиотеки
from pygame import *
import os
import pyganim

# Объявляем переменные для размера иконки платформ
PLATFORM_WIDTH = 32 # Ширина
PLATFORM_HEIGHT = 32 # Высота
PLATFORM_COLOR = '#000000' # Цвет
ICON_DIR = os.path.dirname(__file__) # Полный путь к каталогу файлов

ANIMATION_BLOCKTELEPORT = [
            ('%s/blocks/portal1.png' % ICON_DIR),
            ('%s/blocks/portal2.png' % ICON_DIR)]

ANIMATION_PIROG = [
            ('%s/blocks/pirog_l.png' % ICON_DIR),
            ('%s/blocks/pirog_r.png' % ICON_DIR)]

ANIMATION_WATERBLOCK = [
            ('%s/blocks/waterBlock1.png' % ICON_DIR),
            ('%s/blocks/waterBlock2.png' % ICON_DIR)]
 
class Platform(sprite.Sprite): # Создаём класс платформы
    def __init__(self, x, y):
        sprite.Sprite.__init__(self)
        self.image = Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
        self.image.fill(Color(PLATFORM_COLOR))
        self.image = image.load('%s/blocks/platform.png' % ICON_DIR)
        self.rect = Rect(x, y, PLATFORM_WIDTH, PLATFORM_HEIGHT)
        
class Platform2(sprite.Sprite):
    def __init__(self, x, y):
        sprite.Sprite.__init__(self)
        self.image = Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
        self.image.fill(Color(PLATFORM_COLOR))
        self.image = image.load('%s/blocks/platform2.png' % ICON_DIR)
        self.rect = Rect(x, y, PLATFORM_WIDTH, PLATFORM_HEIGHT)
        
class WaterBlock(Platform):
    def __init__(self, x, y):
        Platform.__init__(self, x,y)
        boltAnim = []
        for anim in ANIMATION_WATERBLOCK:
            boltAnim.append((anim, 0.9))
        self.boltAnim = pyganim.PygAnimation(boltAnim)
        self.boltAnim.play()
        
    def update(self):
        self.image.fill(Color(PLATFORM_COLOR))
        self.boltAnim.blit(self.image, (0, 0))

class BlockDie(Platform): # От класса платформы создаём класс смертельного блока
    def __init__(self, x, y):
        Platform.__init__(self, x, y)
        self.image = image.load("%s/blocks/dieBlock.png" % ICON_DIR)

class BlockTeleport(Platform): # То же самое и с классом портала
    def __init__(self, x, y, goX,goY):
        Platform.__init__(self, x, y)
        self.goX = goX # Координаты перемещения 
        self.goY = goY
        boltAnim = []
        for anim in ANIMATION_BLOCKTELEPORT:
            boltAnim.append((anim, 0.3))
        self.boltAnim = pyganim.PygAnimation(boltAnim)
        self.boltAnim.play()
        
    def update(self): 
        self.image.fill(Color(PLATFORM_COLOR))
        self.boltAnim.blit(self.image, (0, 0))

class Pirog(Platform): # И с классом пирога
    def __init__(self, x, y):
        Platform.__init__(self, x,y)
        boltAnim = []
        for anim in ANIMATION_PIROG:
            boltAnim.append((anim, 0.8))
        self.boltAnim = pyganim.PygAnimation(boltAnim)
        self.boltAnim.play()
        
    def update(self):
        self.image.fill(Color(PLATFORM_COLOR))
        self.boltAnim.blit(self.image, (0, 0))
