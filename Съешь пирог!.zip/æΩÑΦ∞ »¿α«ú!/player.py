# Импортируем библиотеки
from pygame import *
import pyganim
import os
import blocks

MOVE_SPEED = 4 # Задаём скорость передвижения
WIDTH = 22 # Задаём ширину персонажа
HEIGHT = 32 # Задаём высоту персонажа
COLOR = '#888888' # Задаём цвет
JUMP_POWER = 8 # Задаём силу прыжка
GRAVITY = 0.35 # Устанавливаем силу гравитации
ANIMATION_DELAY = 0.1 # Задаём скорость смены кадров
ICON_DIR = os.path.dirname(__file__) 

ANIMATION_RIGHT = [('%s/gg/r1.png' % ICON_DIR),  
            ('%s/gg/r2.png' % ICON_DIR),
            ('%s/gg/r3.png' % ICON_DIR),
            ('%s/gg/r4.png' % ICON_DIR),
            ('%s/gg/r5.png' % ICON_DIR)]
ANIMATION_LEFT = [('%s/gg/l1.png' % ICON_DIR),
            ('%s/gg/l2.png' % ICON_DIR),
            ('%s/gg/l3.png' % ICON_DIR),
            ('%s/gg/l4.png' % ICON_DIR),
            ('%s/gg/l5.png' % ICON_DIR)]
ANIMATION_JUMP_LEFT = [('%s/gg/jl.png' % ICON_DIR, 0.1)]
ANIMATION_JUMP_RIGHT = [('%s/gg/jr.png' % ICON_DIR, 0.1)]
ANIMATION_JUMP = [('%s/gg/j.png' % ICON_DIR, 0.1)]
ANIMATION_STAY = [('%s/gg/0.png' % ICON_DIR, 0.1)]

class Player(sprite.Sprite):
    def __init__(self, x, y):
        sprite.Sprite.__init__(self)
        self.xvel = 0   # Скорость горизонтального перемещения. Если 0 - стоит на месте
        self.startX = x # Начальные координаты
        self.startY = y
        self.yvel = 0 # Скорость вертикального перемещения
        self.onGround = False 
        self.image = Surface((WIDTH,HEIGHT))
        self.image.fill(Color(COLOR))
        self.rect = Rect(x, y, WIDTH, HEIGHT) # Создаём границы персонажа
        self.image.set_colorkey(Color(COLOR)) # Делаем фон прозрачным

        boltAnim = [] # Анимация движения вправо
        for anim in ANIMATION_RIGHT:
            boltAnim.append((anim, ANIMATION_DELAY))
        self.boltAnimRight = pyganim.PygAnimation(boltAnim)
        self.boltAnimRight.play()
        
        boltAnim = [] # Анимация движения влево
        for anim in ANIMATION_LEFT:
            boltAnim.append((anim, ANIMATION_DELAY))
        self.boltAnimLeft = pyganim.PygAnimation(boltAnim)
        self.boltAnimLeft.play()
        
        self.boltAnimStay = pyganim.PygAnimation(ANIMATION_STAY)
        self.boltAnimStay.play()
        self.boltAnimStay.blit(self.image, (0, 0)) 
        
        self.boltAnimJumpLeft= pyganim.PygAnimation(ANIMATION_JUMP_LEFT)
        self.boltAnimJumpLeft.play()
        
        self.boltAnimJumpRight= pyganim.PygAnimation(ANIMATION_JUMP_RIGHT)
        self.boltAnimJumpRight.play()
        
        self.boltAnimJump= pyganim.PygAnimation(ANIMATION_JUMP)
        self.boltAnimJump.play()
        
        self.winner = False
        

    def update (self, left, right, up, platforms): # Для описания поведения объектов
        
        if up:
            if self.onGround: # Сможем прыгать только тогда, когда сможем оттолкнуться
                self.yvel = -JUMP_POWER
            self.image.fill(Color(COLOR))
            self.boltAnimJump.blit(self.image, (0, 0))
                       
        if left:
            self.xvel = -MOVE_SPEED 
            self.image.fill(Color(COLOR))
            if up: 
                self.boltAnimJumpLeft.blit(self.image, (0, 0))
            else:
                self.boltAnimLeft.blit(self.image, (0, 0))
 
        if right:
            self.xvel = MOVE_SPEED 
            self.image.fill(Color(COLOR))
            if up:
                self.boltAnimJumpRight.blit(self.image, (0, 0))
            else:
                self.boltAnimRight.blit(self.image, (0, 0))
         
        if not (left or right): # Стоим, когда нет указаний идти
            self.xvel = 0
            if not up:
                self.image.fill(Color(COLOR))
                self.boltAnimStay.blit(self.image, (0, 0))
            
        if not self.onGround:
            self.yvel +=  GRAVITY
            
        self.onGround = False;    
        self.rect.y += self.yvel
        self.collide(0, self.yvel, platforms)

        self.rect.x += self.xvel 
        self.collide(self.xvel, 0, platforms)
        
   
    def collide(self, xvel, yvel, platforms):
        for p in platforms:
            if sprite.collide_rect(self, p): # Если есть пересечение платформы с игроком
                if isinstance(p, blocks.BlockDie): # Если сталкивается с шипованными платформами
                       self.die() # То умирает
                elif isinstance(p, blocks.BlockTeleport): # Если сталкивается с телепортом
                       self.teleporting(p.goX, p.goY) # Телепортируемся
                elif isinstance(p, blocks.Pirog): # Если сталкивается с пирогом
                       self.winner = True # То выигрываем
                else:
                    if xvel > 0:                       # Если движется вправо
                        self.rect.right = p.rect.left  # То не движется вправо

                    if xvel < 0:                       # Если движется влево
                        self.rect.left = p.rect.right  # То не движется влево

                    if yvel > 0:                       # Если падает вниз
                        self.rect.bottom = p.rect.top  # То не падает вниз
                        self.onGround = True           # Становится на твёрдую поверхность
                        self.yvel = 0                  # Энергия падения пропадает

                    if yvel < 0:                       # Если движется вверх
                        self.rect.top = p.rect.bottom  # То не движется вверх
                        self.yvel = 0                  # Энергия прыжка пропадает

    def die(self): # Поведение при смерти
        time.wait(500)
        self.teleporting(self.startX, self.startY)

    def teleporting(self, goX, goY): # Поведение при перемещении по телепорту
        self.rect.x = goX
        self.rect.y = goY
