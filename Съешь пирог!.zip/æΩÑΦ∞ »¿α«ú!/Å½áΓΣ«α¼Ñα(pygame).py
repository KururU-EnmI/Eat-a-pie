import pygame # Импортируем библиотеку pygame
from pygame import *
from player import *
from blocks import *

# Объявляем переменные для создания окна
WIN_WIDTH = 800 # Ширина
WIN_HEIGHT = 640 # Высота
DISPLAY = (WIN_WIDTH, WIN_HEIGHT) # Группируем ширину и высоту в одну переменную
bg = pygame.image.load('bg.png') # Загружаем фон
icon = pygame.image.load('icon_pygame.png')

FILE_DIR = os.path.dirname(__file__) # Полный путь к каталогу файлов

class Camera(object): # Создаём класс Camera для динамичной камеры
    def __init__(self, camera_func, width, height):
        self.camera_func = camera_func
        self.state = Rect(0, 0, width, height)

    def apply(self, target):
        return target.rect.move(self.state.topleft)

    def update(self, target):
        self.state = self.camera_func(self.state, target.rect)
        
def camera_configure(camera, target_rect): # Добавляем начальное конфигурирование камеры
    l, t, _, _ = target_rect
    _, _, w, h = camera
    l, t = -l+WIN_WIDTH / 2, -t+WIN_HEIGHT / 2

    l = min(0, l)                           # Камера не движется дальше левой границы
    l = max(-(camera.width-WIN_WIDTH), l)   # Камера не движется дальше правой границы
    t = max(-(camera.height-WIN_HEIGHT), t) # Камера не движется дальше нижнеей границы
    t = min(0, t)                           # Камера не движется дальше верхней гранциы

    return Rect(l, t, w, h)        


def loadLevel():
    global playerX, playerY # Объявляем глобальные переменные, координаты персонажа

    levelFile = open('%s/levels/level1.txt' % FILE_DIR)
    line = ' '
    commands = []
    while line[0] != '/': # Пока не найден символ завершения файла:
        line = levelFile.readline() # Считываем построчно
        if line[0] == '[': # Если найден символ начала уровня, то:
            while line[0] != ']': # Пока не найден символ конца уровня:
                line = levelFile.readline() #Считываем уровень построчно
                if line[0] != ']': # Если найден символ конца уровня, то:
                    endLine = line.find('|') # Ищем символ конца строки
                    level.append(line[0: endLine]) # Добавляем в уровень строку от начала и до символа "|"
        
                    
        if line[0] != '': # Если строка не пустая 
         commands = line.split() # То разбиваем её на отдельные команды
         if len(commands) > 1: # Если кол-во команд > 1, то ищем след. команды
            if commands[0] == 'player': # Если первая команда - player 
                playerX= int(commands[1]) # То записываем координаты персонажа
                playerY = int(commands[2])
            if commands[0] == 'portal':  # Если первая команда - portal, то создаём портал
                tp = BlockTeleport(int(commands[1]),int(commands[2]),int(commands[3]),int(commands[4]))
                entities.add(tp)
                platforms.append(tp)
                animatedEntities.add(tp)


def main():
    loadLevel() # Загружаем уровень
    pygame.init() # Инициация PyGame
    screen = pygame.display.set_mode(DISPLAY) # Создаём окно
    pygame.display.set_caption('Съешь пирог!') # Добавляем название окна
    pygame.display.set_icon(icon)
    bg = pygame.image.load('%s/bg.png' % FILE_DIR) # Создаём видимую поверхность, используем как фон      
    
    left = right = False # Поумолчанию стоим
    up = False
    
    hero = Player(playerX,playerY) # Создаём персонажа по указанным в уровне координатам
    entities.add(hero)
    
    timer = pygame.time.Clock() # Ограничение кол-ва кадров в секунду
    x=y=0 
    for row in level: 
        for col in row: 
            if col == '-': # Создание обычной платформы
                pf = Platform(x,y)
                entities.add(pf)
                platforms.append(pf)
            if col == '=': 
                pf2 = Platform2(x,y)
                entities.add(pf2)
                platforms.append(pf2)
            if col == 'W': 
                wb = WaterBlock(x,y)
                entities.add(wb)
                platforms.append(wb)
                animatedEntities.add(wb)
            if col == '*': # Создание смертельной платформы
                bd = BlockDie(x,y)
                entities.add(bd)
                platforms.append(bd)
            if col == 'P': # Создание пирога
                pi = Pirog(x,y)
                entities.add(pi)
                platforms.append(pi)
                animatedEntities.add(pi)

            x += PLATFORM_WIDTH # Блоки платформы ставятся на ширине блоков
        y += PLATFORM_HEIGHT    # Аналогично с высотой
        x = 0                   # На каждой новой строке начинаем с нуля
    
    total_level_width  = len(level[0]) * PLATFORM_WIDTH # Вычисляем ширину уровня
    total_level_height = len(level) * PLATFORM_HEIGHT   # Высчитываем высоту уровня
    
    camera = Camera(camera_configure, total_level_width, total_level_height) 

    while not hero.winner: # Основной цикл программы
        timer.tick(60)
        for e in pygame.event.get(): # Обрабатываем события
            if e.type == pygame.QUIT:
                pygame.quit() 
            if e.type == KEYDOWN and e.key == K_UP:    # Проверка событий
                up = True
            if e.type == KEYDOWN and e.key == K_LEFT:    
                left = True
            if e.type == KEYDOWN and e.key == K_RIGHT:
                right = True

            if e.type == KEYUP and e.key == K_UP:
                up = False
            if e.type == KEYUP and e.key == K_RIGHT:
                right = False
            if e.type == KEYUP and e.key == K_LEFT:
                left = False

        screen.blit(bg, (0,0)) # Каждое действие событие необходимо прорисовывать

        animatedEntities.update() # Показываем все анимации
        camera.update(hero) # Центризируем камеру относительно персонажа 
        hero.update(left, right, up, platforms) # Обновление движений персонажа по платформам 
        for e in entities:
            screen.blit(e.image, camera.apply(e))
        pygame.display.update() # Обновление и вывод всех изменений на экран

level = []
entities = pygame.sprite.Group() # Все обьекты
animatedEntities = pygame.sprite.Group() # Все анимированные объекты, кроме персонажа
platforms = [] # То, во что будем врезатья или опираться

if __name__ == '__main__':
    main()
